#' @importFrom tibble tibble
NULL

#' spec.
#'
#' A txt file version of the Denovix Spectrophotometry data.
#'
#'
"spec"

#' rna1.
#'
#' An excel file version of the Denovix Spectrophotometry data.
#'
#'
"rna1"

#' rna2.
#'
#' A csv file version of the Denovix Spectrophotometry data.
#'
#'
"rna2"

#' rna3.
#'
#' A csv file version of the Denovix Spectrophotometry data.
#'
#'
"rna3"





